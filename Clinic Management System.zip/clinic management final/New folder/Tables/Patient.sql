

clear screen;

drop table Patient cascade constraints;


create table Patient (
	p_id int, 
	p_name varchar2(20), 
	p_phone number(12), 
	gender varchar2(7), 
	age int,
	weight float,
        PRIMARY KEY(p_id)); 


insert into patient (p_id, p_name, p_phone, gender, age, weight) values (1, 'Nishat Farzana', '01685015080', 'Female', 25, 54); 
insert into patient (p_id, p_name, p_phone, gender, age, weight) values (2, 'Zarin Tasneem', '01521494774', 'Female', 23, 52);
insert into patient (p_id, p_name, p_phone, gender, age, weight) values (3, 'Tahsin Tasnim Mim', '01766999954', 'Female', 23, 57);
insert into patient (p_id, p_name, p_phone, gender, age, weight) values (4, 'Sadia Tasnim', '01766999984', ' Female', 21, 67);
insert into patient (p_id, p_name, p_phone, gender, age, weight) values (5, 'Robin Bahadur', '01766599924', 'Male', 12, 47);
insert into patient (p_id, p_name, p_phone, gender, age, weight) values (6, 'Samir Sadek', '01961697961', 'Male', 9, 62);

commit;
 
