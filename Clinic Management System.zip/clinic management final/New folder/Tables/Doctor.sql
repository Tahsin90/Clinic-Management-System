

clear screen;

drop table doctor cascade constraints;

create table doctor (
	D_id int,
	D_name varchar2(30),
	Department varchar2(20),
	D_phone varchar2(12),
        PRIMARY KEY(D_id)); 


insert into doctor (D_id,D_name,Department,D_phone) values (1, 'Dr. A', 'ENT','123'); 
insert into doctor (D_id,D_name,Department,D_phone) values (2, 'Dr. B', 'medicine', '456'); 
insert into doctor (D_id,D_name,Department,D_phone) values (3, 'Dr. C', 'SKIN', '456'); 
insert into doctor (D_id,D_name,Department,D_phone) values (4, 'Dr.D', 'Orthopedic', '123'); 
insert into doctor (D_id,D_name,Department,D_phone) values (5, 'Dr. E', 'Orthopedic', '123'); 
insert into doctor (D_id,D_name,Department,D_phone) values (6, 'Dr. F', 'Orthopedic', '123'); 
insert into doctor (D_id,D_name,Department,D_phone) values (7, 'Dr. G', 'Orthopedic', '123'); 
insert into doctor (D_id,D_name,Department,D_phone) values (8, 'Dr. H', 'medicine', '123'); 
insert into doctor (D_id,D_name,Department,D_phone) values (9, 'Dr. I', 'medicine', '123'); 
insert into doctor (D_id,D_name,Department,D_phone) values (10, 'Dr. J', 'medicine', '123'); 
insert into doctor (D_id,D_name,Department,D_phone) values (11, 'Dr. K', 'medicine', '123'); 
insert into doctor (D_id,D_name,Department,D_phone) values (12, 'Dr. K', 'medicine', '123'); 
insert into doctor (D_id,D_name,Department,D_phone) values (13, 'Dr. K', 'medicine', '123'); 
insert into doctor (D_id,D_name,Department,D_phone) values (14, 'Dr. K', 'medicine', '123'); 
insert into doctor (D_id,D_name,Department,D_phone) values (15, 'Dr. G', 'medicine', '123'); 
insert into doctor (D_id,D_name,Department,D_phone) values (16, 'Dr. G', 'medicine', '123'); 



commit;

