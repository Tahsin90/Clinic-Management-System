
clear screen;

drop table doctor2 cascade constraints;
drop table Patient2 cascade constraints;
drop table room2 cascade constraints;

create table doctor2 (
	D_id int,
	D_name varchar2(30),
	Department varchar2(20),
	D_phone varchar2(12),
        PRIMARY KEY(D_id));

create table Patient2 (
	p_id int, 
	p_name varchar2(20), 
	p_phone number(12), 
	gender varchar2(7), 
	age int,
	weight int,
        PRIMARY KEY(p_id)); 

create table room2 (
	P_id int,
        Room_no int,
	Status varchar2(30),
	Type varchar2(20),
        PRIMARY KEY(Room_no));

commit;