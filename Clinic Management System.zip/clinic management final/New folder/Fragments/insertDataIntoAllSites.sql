set serveroutput on;



declare
pat_age int;





--for doctor table

cursor d_cur1 is
select D_id,D_name,Department,D_phone from doctor
where Department = 'SKIN';

cursor d_cur2 is
select D_id,D_name,Department,D_phone from doctor
where Department = 'medicine';


doc_id int;
doc_name varchar2(30);
doc_department varchar2(20);
doc_phone varchar2(12);


--for patient table

cursor p_cur1 is
select p_id, p_name, p_phone, gender, age, weight from patient
where age < 15;

cursor p_cur2 is
select p_id, p_name, p_phone, gender, age, weight from patient
where age > 15;

pat_id int; 
pat_name varchar2(20); 
pat_phone number(12);
pat_gender varchar2(7); 
pat_page int;
pat_weight int;


--for room table

cursor r_cur1 is
select Room_no,P_id,Status,Type from Room
where Type = 'CABIN' ;

cursor r_cur2 is
select Room_no,P_id,Status,Type from Room
where Type = 'WARD' ;


r_Room int;
r_id int;
r_Status varchar2(30);
r_Type varchar2(20);



begin
	open d_cur1;
	loop
		fetch d_cur1 into doc_id,doc_name,doc_department,doc_phone;
		exit when d_cur1%notFound;

		insert into doctor1@nishat values(doc_id,doc_name,doc_department,doc_phone);
	end loop;
	close d_cur1;

	open d_cur2;
	loop
		fetch d_cur2 into doc_id,doc_name,doc_department,doc_phone;
		exit when d_cur2%notFound;

		insert into doctor2@sadia values(doc_id,doc_name,doc_department,doc_phone);
	end loop;
	close d_cur2;


	
	open p_cur1;
	loop
		fetch p_cur1 into pat_id,pat_name,pat_phone,pat_gender,pat_age,pat_weight;
		exit when p_cur1%notFound;

		insert into patient1@nishat values(pat_id,pat_name,pat_phone,pat_gender,pat_age,pat_weight);
	end loop;
	close p_cur1;

	open p_cur2;
	loop
		fetch p_cur2 into pat_id,pat_name,pat_phone,pat_gender,pat_age,pat_weight;
		exit when p_cur2%notFound;

		insert into patient2@sadia values(pat_id,pat_name,pat_phone,pat_gender,pat_age,pat_weight);
	end loop;
	close p_cur2;
	

	
	/*open r_cur1;
	loop
		fetch r_cur1 into r_Room, r_id, r_Status, r_Type;
		exit when r_cur1%notFound;

		insert into room1@nishat values(r_Room, r_id, r_Status, r_Type);
	end loop;
	close r_cur1;

	open r_cur2;
	loop
		fetch r_cur2 into r_Room, r_id, r_Status, r_Type;
		exit when r_cur2%notFound;

		insert into room2@sadia values(r_Room, r_id, r_Status, r_Type);
	end loop;
	close r_cur2;*/

end;
/